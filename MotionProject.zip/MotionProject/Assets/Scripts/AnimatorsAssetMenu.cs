using UnityEditor.Animations;
using UnityEngine;

[CreateAssetMenu]
public class AnimatorsAssetMenu : ScriptableObject
{
    public AnimatorController animatorIdle;
    public AnimatorController animatorWalk;
    public AnimatorController animatorRun;
    public AnimatorController animatorJump;
}