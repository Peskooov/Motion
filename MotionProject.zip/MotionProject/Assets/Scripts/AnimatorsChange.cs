using UnityEngine;

public class AnimatorsChange : MonoBehaviour
{
    [SerializeField] private PlayerInputController playerInputController;
    [SerializeField] private AnimatorsAssetMenu assetMenu;
    [SerializeField] private Animator animator;

    private void Start()
    {
        playerInputController.IdleEvent += OnIdle;
        playerInputController.WalkEvent += OnWalk;
        playerInputController.RunEvent += OnRun;
        playerInputController.JumpEvent += OnJump;
    }

    private void OnDestroy()
    {
        playerInputController.IdleEvent -= OnIdle;
        playerInputController.WalkEvent -= OnWalk;
        playerInputController.RunEvent -= OnRun;
        playerInputController.JumpEvent -= OnJump;
    }
    
    private void OnIdle()
    {
        ChangeController(assetMenu.animatorIdle);
    }

    private void OnWalk()
    {
        ChangeController(assetMenu.animatorWalk);
    }

    private void OnRun()
    {
        ChangeController(assetMenu.animatorRun);
    }

    private void OnJump()
    {
        ChangeController(assetMenu.animatorJump);
    }

    private void ChangeController(RuntimeAnimatorController newRuntimeAnimatorController)
    {
        animator.runtimeAnimatorController = newRuntimeAnimatorController;
    }
}